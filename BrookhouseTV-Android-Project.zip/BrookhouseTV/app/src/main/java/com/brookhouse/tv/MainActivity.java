package com.brookhouse.tv;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String STREAM_URL = "http://192-168-4-119-via-1:8086/0.m3u8";
    private static final String NETX_PACKAGE = "com.nikstudios.netxplayer";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        openBrookhouseStream();
    }

    private void openBrookhouseStream() {
        Uri stream = Uri.parse(STREAM_URL);
        Intent netx = new Intent(Intent.ACTION_VIEW, stream);
        netx.setPackage(NETX_PACKAGE);
        netx.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        try {
            startActivity(netx);
        } catch (ActivityNotFoundException e) {
            try {
                Intent fallback = new Intent(Intent.ACTION_VIEW, stream);
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(fallback);
            } catch (ActivityNotFoundException e2) {
                Toast.makeText(this, "NetX Player is not installed.", Toast.LENGTH_LONG).show();
            }
        }
        finish();
    }
}
