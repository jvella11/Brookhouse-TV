# Brookhouse TV

Android TV / Google TV launcher tile that opens the Brookhouse HLS stream directly in NetX Player.

Stream:
`http://192-168-4-119-via-1:8086/0.m3u8`

NetX package:
`com.nikstudios.netxplayer`

The included GitHub Actions workflow builds an installable debug APK named `Brookhouse-TV.apk`.
